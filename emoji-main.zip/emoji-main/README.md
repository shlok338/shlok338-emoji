# emoji
emoji shlok
